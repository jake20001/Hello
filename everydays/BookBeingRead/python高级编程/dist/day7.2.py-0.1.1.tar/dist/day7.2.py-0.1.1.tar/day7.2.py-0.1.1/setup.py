# -*- coding:utf-8 -*-
# -------------------------------
# ProjectName : autoDemo
# Author : zhangjk
# CreateTime : 2020/12/5 18:04
# FileName : day7.4
# Description : 
# --------------------------------
from setuptools import setup

setup(name='day7.2.py',version='0.1.1')

